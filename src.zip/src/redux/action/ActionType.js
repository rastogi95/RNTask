export const ISLOGIN = 'ISLOGIN';
