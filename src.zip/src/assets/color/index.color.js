import common from './common.json';

export const Color = {
  ...common,
};
