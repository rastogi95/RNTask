import common from './common';

export const ImageConst = {
  ...common,
};
