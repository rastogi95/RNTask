const IMG_DIRECTORY = '../../images/';

export default {
  daubleTabIcon: require(IMG_DIRECTORY + 'daubleTabPhone.png'),
  swipeIcon: require(IMG_DIRECTORY + 'swipe.png'),
  artIcon: require(IMG_DIRECTORY + 'art.png'),
  layerIcon: require(IMG_DIRECTORY + 'Layer.png'),
  path: require(IMG_DIRECTORY + 'Path.png'),
  cross: require(IMG_DIRECTORY + 'metro-cross.png'),
};
