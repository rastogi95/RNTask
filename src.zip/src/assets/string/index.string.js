import common from './common.json';

export const Strings = {
  ...common,
};
